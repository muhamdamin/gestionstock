package com.elife.gestion.buisness.services;

    import org.springframework.security.core.Authentication;

import com.elife.gestion.Dao.entity.Utilisateur;
import com.elife.gestion.dto.AuthenticationUserDTO;
import com.elife.gestion.exception.DuplicateUserException;

public interface AuthenticationService {
   
    Utilisateur register(Utilisateur user) throws DuplicateUserException;
   AuthenticationUserDTO login(Authentication authentication);
}
