package com.elife.gestion.controller;

import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elife.gestion.buisness.services.UtilisateurService;
import com.elife.gestion.dto.ChangerMotDePasseUtilisateurDto;
import com.elife.gestion.dto.UtilisateurDto;

@RestController
@RequestMapping("/gestiondestock/v1/utilisateurs")
@PreAuthorize("hasAnyRole('ADMIN','USER')")
public class UtilisateurController {
    
     final UtilisateurService utilisateurService;

  public UtilisateurController(UtilisateurService utilisateurService) {
    this.utilisateurService = utilisateurService;
  }

    @PostMapping("/create")
    @PreAuthorize("hasAuthority('WRITE_PRIVILEGE') and hasRole('ADMIN')")
  public UtilisateurDto save(@RequestBody UtilisateurDto dto) {
    return utilisateurService.save(dto);
  }

  @PostMapping("/update/password")
  public UtilisateurDto changerMotDePasse(@RequestBody ChangerMotDePasseUtilisateurDto dto) {
    return utilisateurService.changerMotDePasse(dto);
  }

  @GetMapping("/{idUtilisateur}")
  public UtilisateurDto findById(@PathVariable("idUtilisateur") Integer id) {
    return utilisateurService.findById(id);
  }

  @GetMapping("/find/{email}")
  public UtilisateurDto findByEmail(@PathVariable("email") String email) {
    return utilisateurService.findByEmail(email);
  }

  @GetMapping("/all")
  
  public List<UtilisateurDto> findAll() {
    return utilisateurService.findAll();
  }

    @DeleteMapping("/delete/{idUtilisateur}")
  public void delete(@PathVariable("idUtilisateur") Integer id) {
    utilisateurService.delete(id);
  }
}