package com.elife.gestion.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elife.gestion.Dao.entity.EtatCommande;
import com.elife.gestion.buisness.services.CommandeClientService;
import com.elife.gestion.dto.CommandeClientDto;
import com.elife.gestion.dto.LigneCommandeClientDto;

@RestController
@RequestMapping("/gestiondestock/v1/commandesclients")
@PreAuthorize("hasAnyRole('ADMIN','USER')")
public class CommandeClientController {

        final CommandeClientService commandeClientService;
    public CommandeClientController(CommandeClientService commandeClientService){
        this.commandeClientService=commandeClientService;
    }
   
     @PostMapping("/create")
     @PreAuthorize("hasAuthority('WRITE_PRIVILEGE') and hasRole('ADMIN')")
  public ResponseEntity<CommandeClientDto> save(@RequestBody CommandeClientDto dto) {
    return ResponseEntity.ok(commandeClientService.save(dto));
  }

    @PatchMapping("/update/etat/{idCommande}/{etatCommande}")
    @PreAuthorize("hasAuthority('UPDATE_PRIVILEGE') and hasRole('ADMIN')")
  public ResponseEntity<CommandeClientDto> updateEtatCommande(@PathVariable("idCommande") Integer idCommande,@PathVariable("etatCommande") EtatCommande etatCommande) {
    return ResponseEntity.ok(commandeClientService.updateEtatCommande(idCommande, etatCommande));
  }

  @PatchMapping("/update/quantite/{idCommande}/{idLigneCommande}/{quantite}")
  @PreAuthorize("hasAuthority('UPDATE_PRIVILEGE') and hasRole('ADMIN')")
  public ResponseEntity<CommandeClientDto> updateQuantiteCommande(@PathVariable("idCommande") Integer idCommande,@PathVariable("idLigneCommande") Integer idLigneCommande,@PathVariable("quantite") BigDecimal quantite) {
    return ResponseEntity.ok(commandeClientService.updateQuantiteCommande(idCommande, idLigneCommande, quantite));
  }

  @PatchMapping("/update/client/{idCommande}/{idClient}")
  @PreAuthorize("hasAuthority('UPDATE_PRIVILEGE') and hasRole('ADMIN')")
  public ResponseEntity<CommandeClientDto> updateClient(@PathVariable("idCommande") Integer idCommande,@PathVariable("idClient") Integer idClient) {
    return ResponseEntity.ok(commandeClientService.updateClient(idCommande, idClient));
  }

  @PatchMapping("/update/article/{idCommande}/{idLigneCommande}/{idArticle}")
  @PreAuthorize("hasAuthority('UPDATE_PRIVILEGE') and hasRole('ADMIN')")
  public ResponseEntity<CommandeClientDto> updateArticle(@PathVariable("idCommande") Integer idCommande,@PathVariable("idLigneCommande") Integer idLigneCommande, @PathVariable("idArticle") Integer idArticle) {
    return ResponseEntity.ok(commandeClientService.updateArticle(idCommande, idLigneCommande, idArticle));
  }

  @DeleteMapping("/delete/article/{idCommande}/{idLigneCommande}")
  @PreAuthorize("hasAuthority('DELETE_PRIVILEGE') and hasRole('ADMIN')")
  public ResponseEntity<CommandeClientDto> deleteArticle(@PathVariable("idCommande") Integer idCommande,@PathVariable("idLigneCommande") Integer idLigneCommande) {
    return ResponseEntity.ok(commandeClientService.deleteArticle(idCommande, idLigneCommande));
  }

   @GetMapping("/{idCommandeClient}")
   @PreAuthorize("hasAuthority('READ_PRIVILEGE') and hasRole('ADMIN')")
  public ResponseEntity<CommandeClientDto> findById(@PathVariable Integer id) {
    return ResponseEntity.ok(commandeClientService.findById(id));
  }

  @GetMapping("/filter/{codeCommandeClient}")
  @PreAuthorize("hasAuthority('READ_PRIVILEGE') and hasRole('ADMIN')")
  public ResponseEntity<CommandeClientDto> findByCode(@PathVariable("codeCommandeClient") String code) {
    return ResponseEntity.ok(commandeClientService.findByCode(code));
  }

  @GetMapping("/all")
  @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
  public ResponseEntity<List<CommandeClientDto>> findAll() {
    return ResponseEntity.ok(commandeClientService.findAll());
  }

  @GetMapping("/lignesCommande/{idCommande}")
  @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
  public ResponseEntity<List<LigneCommandeClientDto>> findAllLignesCommandesClientByCommandeClientId(@PathVariable("idCommande") Integer idCommande) {
    return ResponseEntity.ok(commandeClientService.findAllLignesCommandesClientByCommandeClientId(idCommande));
  }

  @DeleteMapping("/delete/{idCommandeClient}")
  @PreAuthorize("hasAuthority('DELETE_PRIVILEGE') and hasRole('ADMIN')")
  public ResponseEntity<Void> delete(@PathVariable("idCommandeClient") Integer id) {
    commandeClientService.delete(id);
    return ResponseEntity.ok().build();
  } 
}