package com.elife.gestion.buisness.serviceimpl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.elife.gestion.Dao.entity.LigneCommandeClient;
import com.elife.gestion.Dao.entity.LigneCommandeFournisseur;
import com.elife.gestion.Dao.entity.LigneVente;
import com.elife.gestion.buisness.services.ArticleService;
import com.elife.gestion.dto.ArticleDto;
import com.elife.gestion.dto.LigneCommandeClientDto;
import com.elife.gestion.dto.LigneCommandeFournisseurDto;
import com.elife.gestion.dto.LigneVenteDto;
import com.elife.gestion.exception.EntityNotFoundException;
import com.elife.gestion.exception.ErrorCodes;
import com.elife.gestion.exception.InvalidOperationException;
import com.elife.gestion.repository.ArticleRepository;
import com.elife.gestion.repository.LigneCommandeClientRepository;
import com.elife.gestion.repository.LigneCommandeFournisseurRepository;
import com.elife.gestion.repository.LigneVenteRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ArticleServiceImpl implements ArticleService{

    final ArticleRepository articleRepository;
    final LigneVenteRepository venteRepository;
    final LigneCommandeFournisseurRepository commandeFournisseurRepository;
    final LigneCommandeClientRepository commandeClientRepository;
    public ArticleServiceImpl (ArticleRepository articleRepository,LigneVenteRepository venteRepository,LigneCommandeFournisseurRepository commandeFournisseurRepository, LigneCommandeClientRepository commandeClientRepository){
        this.articleRepository=articleRepository;
        this.venteRepository=venteRepository;
        this.commandeClientRepository=commandeClientRepository;
        this.commandeFournisseurRepository=commandeFournisseurRepository;
    }
    @Override
    public ArticleDto save(ArticleDto dto) {
        return ArticleDto.fromEntity(
        articleRepository.save(
            ArticleDto.toEntity(dto)
        )
    );
    }

    @Override
    public ArticleDto findById(Integer id) {
        if (id == null) {
            log.error("Article ID is null");
            return null;
          }
      
          return articleRepository.findById(id).map(ArticleDto::fromEntity)
          .orElseThrow(() ->
          new EntityNotFoundException("Aucun article avec l'ID = " + id + " n' ete trouve dans la BDD",
            ErrorCodes.ARTICLE_NOT_FOUND)
          );
    }

    @Override
    public ArticleDto findByCodeArticle(String codeArticle) {
        if (!StringUtils.hasLength(codeArticle)) {
            log.error("Article CODE is null");
            return null;
          }
      
          return articleRepository.findArticleByCodeArticle(codeArticle)
              .map(ArticleDto::fromEntity)
              .orElseThrow(() ->
                  new EntityNotFoundException(
                      "Aucun article avec le CODE = " + codeArticle + " n' ete trouve dans la BDD",
                      ErrorCodes.ARTICLE_NOT_FOUND)
              );

    }

    @Override
    public List<ArticleDto> findAll() {
       return articleRepository.findAll().stream()
        .map(ArticleDto::fromEntity)
        .collect(Collectors.toList());
    }

    @Override
    public List<LigneVenteDto> findHistoriqueVentes(Integer idArticle) {
        return venteRepository.findAllByArticleId(idArticle).stream()
        .map(LigneVenteDto::fromEntity)
        .collect(Collectors.toList());
    }

    @Override
    public List<LigneCommandeClientDto> findHistoriaueCommandeClient(Integer idArticle) {
        return commandeClientRepository.findAllByArticleId(idArticle).stream()
        .map(LigneCommandeClientDto::fromEntity)
        .collect(Collectors.toList());
    }

    @Override
    public List<LigneCommandeFournisseurDto> findHistoriqueCommandeFournisseur(Integer idArticle) {
        return commandeFournisseurRepository.findAllByArticleId(idArticle).stream()
        .map(LigneCommandeFournisseurDto::fromEntity)
        .collect(Collectors.toList());
    }

    @Override
    public List<ArticleDto> findAllArticleByIdCategory(Integer idCategory) {
        return articleRepository.findAllByCategoryId(idCategory).stream()
        .map(ArticleDto::fromEntity)
        .collect(Collectors.toList());
    }

    @Override
    public void delete(Integer id) {
       if (id == null) {
      log.error("Article ID is null");
      return;
    }
    List<LigneCommandeClient> ligneCommandeClients = commandeClientRepository.findAllByArticleId(id);
    if (!ligneCommandeClients.isEmpty()) {
      throw new InvalidOperationException("Impossible de supprimer un article deja utilise dans des commandes client", ErrorCodes.ARTICLE_ALREADY_IN_USE);
    }
    List<LigneCommandeFournisseur> ligneCommandeFournisseurs = commandeFournisseurRepository.findAllByArticleId(id);
    if (!ligneCommandeFournisseurs.isEmpty()) {
      throw new InvalidOperationException("Impossible de supprimer un article deja utilise dans des commandes fournisseur",
          ErrorCodes.ARTICLE_ALREADY_IN_USE);
    }
    List<LigneVente> ligneVentes = venteRepository.findAllByArticleId(id);
    if (!ligneVentes.isEmpty()) {
      throw new InvalidOperationException("Impossible de supprimer un article deja utilise dans des ventes",
          ErrorCodes.ARTICLE_ALREADY_IN_USE);
    }
    articleRepository.deleteById(id);
    }
    
}