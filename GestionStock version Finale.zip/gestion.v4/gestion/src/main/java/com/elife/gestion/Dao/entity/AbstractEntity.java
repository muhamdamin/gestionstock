package com.elife.gestion.Dao.entity;

import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDateTime;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;


import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.PrePersist;
import lombok.Data;



@Data
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public class AbstractEntity implements Serializable{
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @CreatedDate
@Column(name="creation_Date",nullable = false)

    private LocalDateTime creationDate; 


@LastModifiedDate
@Column(name = "lastModified_Date")

    private LocalDateTime lastUpdateDate;

@PrePersist
    protected void onCreate() {
        creationDate = LocalDateTime.now();
    }

    
}