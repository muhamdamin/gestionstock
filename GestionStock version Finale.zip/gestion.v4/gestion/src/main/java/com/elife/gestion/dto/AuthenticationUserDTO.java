package com.elife.gestion.dto;

import java.util.List;

import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.elife.gestion.Dao.entity.Utilisateur;

public record AuthenticationUserDTO(Integer id,
String email,
List<String> roles) {
     public AuthenticationUserDTO(Integer id, String email, List<String> roles) {
        this.id= id;
        this.email=email;
        this.roles=roles;
    }

    public static AuthenticationUserDTO toAuthenticationUserDTO(Utilisateur user) {
        List<String> roles = user.getRole().getAuthorities()
                .stream()
                .map(SimpleGrantedAuthority::getAuthority)
                .toList();
        return new AuthenticationUserDTO(user.getId(), user.getEmail(), roles);
    }

}
