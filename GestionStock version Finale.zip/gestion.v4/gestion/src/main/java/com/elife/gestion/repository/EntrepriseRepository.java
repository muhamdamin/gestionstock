package com.elife.gestion.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.elife.gestion.Dao.entity.Entreprise;

public interface EntrepriseRepository extends JpaRepository<Entreprise,Integer>{
    
}