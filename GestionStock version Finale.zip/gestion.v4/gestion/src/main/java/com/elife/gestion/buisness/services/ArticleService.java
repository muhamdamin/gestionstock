package com.elife.gestion.buisness.services;

import java.util.List;

import com.elife.gestion.dto.ArticleDto;
import com.elife.gestion.dto.LigneCommandeClientDto;
import com.elife.gestion.dto.LigneCommandeFournisseurDto;
import com.elife.gestion.dto.LigneVenteDto;

public interface ArticleService {

    ArticleDto save(ArticleDto dto);

  ArticleDto findById(Integer id);

  ArticleDto findByCodeArticle(String codeArticle);

  List<ArticleDto> findAll();

  List<LigneVenteDto> findHistoriqueVentes(Integer idArticle);

  List<LigneCommandeClientDto> findHistoriaueCommandeClient(Integer idArticle);

  List<LigneCommandeFournisseurDto> findHistoriqueCommandeFournisseur(Integer idArticle);

  List<ArticleDto> findAllArticleByIdCategory(Integer idCategory);

  void delete(Integer id);
    
}