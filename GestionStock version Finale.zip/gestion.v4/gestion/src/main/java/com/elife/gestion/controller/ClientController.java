package com.elife.gestion.controller;

import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elife.gestion.buisness.services.ClientService;
import com.elife.gestion.dto.ClientDto;

@RestController
@RequestMapping("/gestiondestock/v1/clients")
@PreAuthorize("hasAnyRole('ADMIN','USER')")
public class ClientController  {
    final ClientService clientService;
    public ClientController(ClientService clientService){
        this.clientService=clientService;
    }
     @PostMapping(value ="/create", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
     @PreAuthorize("hasAuthority('WRITE_PRIVILEGE') and hasRole('ADMIN')")
     public ClientDto save(@RequestBody ClientDto dto) {
        return clientService.save(dto);
    }
   
    @GetMapping(value = "/{idClient}", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasAuthority('READ_PRIVILEGE') and hasRole('ADMIN')")
    public ClientDto findById(@PathVariable("idClient") Integer id) {
        return clientService.findById(id);
    }
   
    @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasAuthority('READ_PRIVILEGE') and hasRole('ADMIN')")
    public ResponseEntity<List<ClientDto>> getAllClients() {
        // Votre logique pour récupérer les clients
        return ResponseEntity.ok(clientService.findAll());
    }
    @DeleteMapping(value = "/delete/{idClient}")
    @PreAuthorize("hasAuthority('DELETE_PRIVILEGE') and hasRole('ADMIN')")
    public void delete(@PathVariable("idClient") Integer id) {
         clientService.delete(id);
    }
}