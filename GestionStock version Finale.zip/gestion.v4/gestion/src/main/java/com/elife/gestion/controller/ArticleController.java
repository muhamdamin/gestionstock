package com.elife.gestion.controller;

import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elife.gestion.buisness.services.ArticleService;
import com.elife.gestion.dto.ArticleDto;
import com.elife.gestion.dto.LigneCommandeClientDto;
import com.elife.gestion.dto.LigneCommandeFournisseurDto;
import com.elife.gestion.dto.LigneVenteDto;

@RestController
@RequestMapping("/gestiondestock/v1/articles")
@PreAuthorize("hasAnyRole('ADMIN','USER')")
public class ArticleController  {

    final ArticleService articleService;
    public ArticleController(ArticleService articleService){
        this.articleService=articleService;
    }
    
     @PostMapping(value = "/create", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
     @PreAuthorize("hasAuthority('WRITE_PRIVILEGE') and hasRole('ADMIN')")
    public ArticleDto save(@RequestBody ArticleDto dto) {
      return articleService.save(dto);
      
    }

    @GetMapping(value ="/{idArticle}" , produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
    public ArticleDto findById(  @PathVariable("idArticle") Integer id ) {
       return articleService.findById(id);
       
       
    }

    @GetMapping(value = "/filter/{codeArticle}", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
    public ArticleDto findByCodeArticle(@PathVariable("idArticle") String codeArticle) {
        return articleService.findByCodeArticle(codeArticle);
    }

    @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
    public List<ArticleDto> findAll() {
       return articleService.findAll();
    }

    @GetMapping(value ="/historique/vente/{idArticle}", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasAuthority('READ_PRIVILEGE') and hasRole('ADMIN')")
    public List<LigneVenteDto> findHistoriqueVentes(@PathVariable("idArticle") Integer idArticle) {
       return articleService.findHistoriqueVentes(idArticle);
    }

    @GetMapping(value = "/historique/commandeclient/{idArticle}", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasAuthority('READ_PRIVILEGE') and hasRole('ADMIN')")
    public List<LigneCommandeClientDto> findHistoriaueCommandeClient(@PathVariable("idArticle") Integer idArticle) {
        return articleService.findHistoriaueCommandeClient(idArticle);
    }

    @GetMapping(value = "/historique/commandefournisseur/{idArticle}", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
    public List<LigneCommandeFournisseurDto> findHistoriqueCommandeFournisseur(@PathVariable("idArticle") Integer idArticle) {
        return  articleService.findHistoriqueCommandeFournisseur(idArticle);
    }

    @GetMapping(value = "/filter/category/{idCategory}", produces = MediaType.APPLICATION_JSON_VALUE)
    @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
    public List<ArticleDto> findAllArticleByIdCategory(@PathVariable("idCategory") Integer idCategory) {
        return articleService.findAllArticleByIdCategory(idCategory);
    }

    @DeleteMapping("/delete/{idArticle}")
    @PreAuthorize("hasAuthority('DELETE_PRIVILEGE') and hasRole('ADMIN')")
    public void delete(@PathVariable("idArticle") Integer id) {
         articleService.delete(id);
    }

    

}