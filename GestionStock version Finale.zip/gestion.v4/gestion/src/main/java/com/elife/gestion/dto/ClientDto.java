package com.elife.gestion.dto;

import java.util.List;

import com.elife.gestion.Dao.entity.Client;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Builder;
import lombok.Data;

@Builder
@Data

public class ClientDto {

    private Integer id;
 
    private String nom;

    private String prenom;
    
    private AdresseDto adresse;

    private String photo;

    private String mail;

    private String numTel;

    private Integer idEntreprise;
    
    @JsonIgnore
    private List<CommandeClientDto> commandClients;
      
     public static ClientDto fromEntity(Client client){
        if(client==null){
         return null;   
        }
        return ClientDto.builder()
        .id(client.getId())
        .nom(client.getNom())
        .numTel(client.getNumTel())
        .prenom(client.getPrenom())
        .adresse(AdresseDto.fromEntity(client.getAdresse()))
        .mail(client.getMail())
        .photo(client.getPhoto())
        .build();
    } 

      
    public static Client toEntity(ClientDto clientdto){
        if(clientdto==null){
         return null;   
        }

        Client client = new Client();
        client.setId(clientdto.getId());
        client.setAdresse(AdresseDto.toEntity(clientdto.getAdresse()));
        client.setNom(clientdto.getNom());

        return client;

}

}