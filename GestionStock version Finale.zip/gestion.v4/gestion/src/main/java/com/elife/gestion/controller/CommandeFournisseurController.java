package com.elife.gestion.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elife.gestion.Dao.entity.EtatCommande;
import com.elife.gestion.buisness.services.CommandeFournisseurService;
import com.elife.gestion.dto.CommandeFournisseurDto;
import com.elife.gestion.dto.LigneCommandeFournisseurDto;

@RestController
@RequestMapping("/gestiondestock/v1/commandesfournisseurs")
@PreAuthorize("hasAnyRole('ADMIN','USER')")
public class CommandeFournisseurController {
    
      final CommandeFournisseurService commandeFournisseurService;

  public CommandeFournisseurController(CommandeFournisseurService commandeFournisseurService) {
    this.commandeFournisseurService = commandeFournisseurService;
  }

 

    @PostMapping("/create")
    @PreAuthorize("hasAuthority('WRITE_PRIVILEGE') and hasRole('ADMIN')")
  public CommandeFournisseurDto save(@RequestBody CommandeFournisseurDto dto) {
    return commandeFournisseurService.save(dto);
  }


 @PatchMapping("/update/etat/{idCommande}/{etatCommande}")
 @PreAuthorize("hasAuthority('UPDATE_PRIVILEGE') and hasRole('ADMIN')")
  public CommandeFournisseurDto updateEtatCommande(@PathVariable("idCommande") Integer idCommande,@PathVariable("etatCommande") EtatCommande etatCommande) {
    return commandeFournisseurService.updateEtatCommande(idCommande, etatCommande);
  }

  @PatchMapping("/update/quantite/{idCommande}/{idLigneCommande}/{quantite}")
  @PreAuthorize("hasAuthority('UPDATE_PRIVILEGE') and hasRole('ADMIN')") 
  public CommandeFournisseurDto updateQuantiteCommande(@PathVariable("idCommande") Integer idCommande,@PathVariable("idLigneCommande") Integer idLigneCommande,@PathVariable("quantite") BigDecimal quantite) {
    return commandeFournisseurService.updateQuantiteCommande(idCommande, idLigneCommande, quantite);
  }

  @PatchMapping("/update/fournisseur/{idCommande}/{idFournisseur}")
  @PreAuthorize("hasAuthority('UPDATE_PRIVILEGE') and hasRole('ADMIN')")

  public CommandeFournisseurDto updateFournisseur(@PathVariable("idCommande") Integer idCommande,@PathVariable("idFournisseur") Integer idFournisseur) {
    return commandeFournisseurService.updateFournisseur(idCommande, idFournisseur);
  }

  @PatchMapping("/update/article/{idCommande}/{idLigneCommande}/{idArticle}")
  @PreAuthorize("hasAuthority('UPDATE_PRIVILEGE') and hasRole('ADMIN')")
  public CommandeFournisseurDto updateArticle(@PathVariable("idCommande") Integer idCommande,@PathVariable("idLigneCommande") Integer idLigneCommande,@PathVariable("idArticle") Integer idArticle) {
    return commandeFournisseurService.updateArticle(idCommande, idLigneCommande, idArticle);
  }

@DeleteMapping("/delete/article/{idCommande}/{idLigneCommande}")
@PreAuthorize("hasAuthority('DELETE_PRIVILEGE') and hasRole('ADMIN')")
  
public CommandeFournisseurDto deleteArticle(@PathVariable("idCommande") Integer idCommande,@PathVariable("idLigneCommande") Integer idLigneCommande) {
    return commandeFournisseurService.deleteArticle(idCommande, idLigneCommande);
  }

@GetMapping ("/{idCommandeFournisseur}")
@PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
  public CommandeFournisseurDto findById(@PathVariable("idCommandeFournisseur") Integer id) {
    return commandeFournisseurService.findById(id);
  }

    @GetMapping ("/filtre/{codeCommandeFournisseur}")
    @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
  public CommandeFournisseurDto findByCode(@PathVariable("codeCommandeFournisseur") String code) {
    return commandeFournisseurService.findByCode(code);
  }

    @GetMapping("/all")
    @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
  public List<CommandeFournisseurDto> findAll() {
    return commandeFournisseurService.findAll();
  }

  @GetMapping("/lignesCommande/{idCommande}")
  @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
  public List<LigneCommandeFournisseurDto> findAllLignesCommandesFournisseurByCommandeFournisseurId(@PathVariable("idCommande")Integer idCommande) {
    return commandeFournisseurService.findAllLignesCommandesFournisseurByCommandeFournisseurId(idCommande);
  }

    @DeleteMapping("/delete/{idCommandeFournisseur}")
    @PreAuthorize("hasAuthority('DELETE_PRIVILEGE') and hasRole('ADMIN')")
  public void delete(@PathVariable("idCommandeFournisseur") Integer id) {
    commandeFournisseurService.delete(id);
  }
}