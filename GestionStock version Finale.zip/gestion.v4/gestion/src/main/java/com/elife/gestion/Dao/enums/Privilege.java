package com.elife.gestion.Dao.enums;

public enum Privilege {
    READ_PRIVILEGE,
    WRITE_PRIVILEGE,
    DELETE_PRIVILEGE,
    UPDATE_PRIVILEGE;
}