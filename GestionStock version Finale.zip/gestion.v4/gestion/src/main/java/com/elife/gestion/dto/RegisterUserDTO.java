package com.elife.gestion.dto;

import org.springframework.security.crypto.password.PasswordEncoder;

import com.elife.gestion.Dao.entity.Utilisateur;
import com.elife.gestion.Dao.enums.Role;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record RegisterUserDTO( @NotBlank(message = "firstname is required") String firstname,
        @NotBlank(message = "lastname is required") String lastname,
        @NotBlank(message = "email is required") @Email(message = "email format is not valid") String email,
        @NotBlank(message = "password is required")  @Size(min = 6, message = "Password must be at most 6 characters long") String password,
        @NotNull Role role) {

             public static Utilisateur fromRegisterUserDTO(RegisterUserDTO registerUserDTO, PasswordEncoder passwordEncoder) {
        Utilisateur user = Utilisateur.builder()
                .nom(registerUserDTO.firstname())
                .prenom(registerUserDTO.lastname())
                .email(registerUserDTO.email())
                .moteDePasse(passwordEncoder.encode(registerUserDTO.password()))
                .role(registerUserDTO.role())
                .build();
        return user;
    }

    public static RegisterUserDTO toRegisterUserDTO(Utilisateur user) {
        return new RegisterUserDTO(user.getNom(),
                user.getPrenom(),
                user.getEmail(),
                user.getMoteDePasse(),
                user.getRole());
    }

}
