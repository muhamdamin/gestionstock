package com.elife.gestion.Dao.entity;

public enum EtatCommande {
    EN_PREPARATION,
  VALIDEE,
  LIVREE
}