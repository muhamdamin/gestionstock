package com.elife.gestion.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.elife.gestion.Dao.entity.Fournisseur;

public interface FournisseurRepository extends JpaRepository<Fournisseur,Integer> {
    
}