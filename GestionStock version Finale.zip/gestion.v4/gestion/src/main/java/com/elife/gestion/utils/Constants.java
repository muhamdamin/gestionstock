package com.elife.gestion.utils;

public interface Constants {
    
    String APP_ROOT = "gestiondestock/v1";

}