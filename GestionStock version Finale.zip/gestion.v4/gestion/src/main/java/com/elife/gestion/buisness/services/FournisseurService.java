package com.elife.gestion.buisness.services;

import java.util.List;

import com.elife.gestion.dto.FournisseurDto;

public interface FournisseurService {
    FournisseurDto save(FournisseurDto dto);

  FournisseurDto findById(Integer id);

  List<FournisseurDto> findAll();

  void delete(Integer id);
}