package com.elife.gestion.controller;

import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elife.gestion.buisness.services.VentesService;
import com.elife.gestion.dto.VentesDto;

@RestController
@RequestMapping("/gestiondestock/v1/ventes")
@PreAuthorize("hasRole('ADMIN')")

public class VentesController {
     final VentesService ventesService;

  public VentesController(VentesService ventesService) {
    this.ventesService = ventesService;
  }

    @PostMapping("/create")
    @PreAuthorize("hasAuthority('WRITE_PRIVILEGE') and hasRole('ADMIN')")
  public VentesDto save(@RequestBody VentesDto dto) {
    return ventesService.save(dto);
  }

    @GetMapping("/{idVente}")
    @PreAuthorize("hasAuthority('READ_PRIVILEGE') and hasRole('ADMIN')")
  public VentesDto findById(@PathVariable("idVente") Integer id) {
    return ventesService.findById(id);
  }

  @GetMapping("/{codeVente}")
  @PreAuthorize("hasAuthority('READ_PRIVILEGE') and hasRole('ADMIN')")
  public VentesDto findByCode(@PathVariable("codeVente") String code) {
    return ventesService.findByCode(code);
  }

  @GetMapping("/all")
  @PreAuthorize("hasAuthority('READ_PRIVILEGE') and hasRole('ADMIN')")
  public List<VentesDto> findAll() {
    return ventesService.findAll();
  }

    @DeleteMapping("/delete/{idVente}")
    @PreAuthorize("hasAuthority('DELETE_PRIVILEGE') and hasRole('ADMIN')")
  public void delete(@PathVariable("idVente") Integer id) {
    ventesService.delete(id);
  }
}