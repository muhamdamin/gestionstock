package com.elife.gestion.Dao.entity;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import com.elife.gestion.Dao.enums.Role;
import com.elife.gestion.Dao.enums.Role.*;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "utilisateurs")
public class Utilisateur extends AbstractEntity implements UserDetails{

 @Column(name = "nom")
  private String nom;

  @Column(name = "prenom")
  private String prenom;

  @Column(name = "email", unique = true, nullable = false)
  private String email;

  @Column(name = "datedenaissance")
  private Instant dateDeNaissance;

  @Column(name = "motdepasse",nullable = false)
  private String moteDePasse;

  @Embedded
  private Adresse adresse;
  @Enumerated(EnumType.STRING)
  @Column(nullable = false)
  private Role role;

  @Column(name = "photo")
  private String photo;

  @ManyToOne
  @JoinColumn(name = "identreprise")
  private Entreprise entreprise;


  
 @ElementCollection(targetClass = Role.class)
    @CollectionTable(name = "user_roles")
    @Enumerated(EnumType.STRING)
    private Set<Role> roles;

  @Override
  public Collection<? extends GrantedAuthority> getAuthorities() {
    return role.getAuthorities();
  }


  @Override
  public String getPassword() {
    return moteDePasse;
  }


  @Override
  public String getUsername() {
    return email;
  } 
  @Override
  public boolean isAccountNonExpired() {
    return true;
 }
 
  @Override
  public boolean isAccountNonLocked() {
    return true;
 }
 
  @Override
  public boolean isCredentialsNonExpired() {
    return true;
 }
 
  @Override
  public boolean isEnabled() {
    return true;
 }
}