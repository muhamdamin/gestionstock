package com.elife.gestion.controller;

import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elife.gestion.buisness.services.FournisseurService;
import com.elife.gestion.dto.FournisseurDto;

@RestController
@RequestMapping( "/gestiondestock/v1/fournisseur")
@PreAuthorize("hasAnyRole('ADMIN','USER')")
public class FournisseurController {

      final FournisseurService fournisseurService;

  public FournisseurController(FournisseurService fournisseurService) {
    this.fournisseurService = fournisseurService;
  }

    @PostMapping("/create")
    @PreAuthorize("hasAuthority('WRITE_PRIVILEGE') and hasRole('ADMIN')")
  public FournisseurDto save(@RequestBody FournisseurDto dto) {
    return fournisseurService.save(dto);
  }

    @GetMapping("/{idFournisseur}")
    @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
  public FournisseurDto findById(@PathVariable("idFournisseur") Integer id) {
    return fournisseurService.findById(id);
  }

  @GetMapping("/all")
  @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
  public List<FournisseurDto> findAll() {
    return fournisseurService.findAll();
  }

    @DeleteMapping("/delete/{idFournisseur}")
    @PreAuthorize("hasAuthority('DELETE_PRIVILEGE') and hasRole('ADMIN')")
  public void delete(@PathVariable("idFournisseur") Integer id) {
    fournisseurService.delete(id);
  }
    
}