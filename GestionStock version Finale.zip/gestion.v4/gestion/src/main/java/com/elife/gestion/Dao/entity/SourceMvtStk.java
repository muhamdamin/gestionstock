package com.elife.gestion.Dao.entity;

public enum SourceMvtStk {
    COMMANDE_CLIENT,
    COMMANDE_FOURNISSEUR,
    VENTE 
}