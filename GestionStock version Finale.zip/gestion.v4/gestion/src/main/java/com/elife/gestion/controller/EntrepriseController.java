package com.elife.gestion.controller;

import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elife.gestion.buisness.services.EntrepriseService;
import com.elife.gestion.dto.EntrepriseDto;

@RestController
@RequestMapping("/gestiondestock/v1/entreprises")
@PreAuthorize("hasAnyRole('ADMIN','USER')")
public class EntrepriseController {
      final EntrepriseService entrepriseService;

  public EntrepriseController(EntrepriseService entrepriseService) {
    this.entrepriseService = entrepriseService;
  }

    @PostMapping("/create")
    @PreAuthorize("hasAuthority('WRITE_PRIVILEGE') and hasRole('ADMIN')")
  public EntrepriseDto save(@RequestBody EntrepriseDto dto) {
    return entrepriseService.save(dto);
  }

    @GetMapping("/{idEntreprise}")
    @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
  public EntrepriseDto findById(@PathVariable("idEntreprise") Integer id) {
    return entrepriseService.findById(id);
  }

  @GetMapping("/all")
  @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")
  public List<EntrepriseDto> findAll() {
    return entrepriseService.findAll();
  }

    @DeleteMapping("/delete/{idEntreprise}")
    @PreAuthorize("hasAuthority('DELETE_PRIVILEGE') and hasRole('ADMIN')")
  public void delete(@PathVariable("idEntreprise") Integer id) {
    entrepriseService.delete(id);
  }
}