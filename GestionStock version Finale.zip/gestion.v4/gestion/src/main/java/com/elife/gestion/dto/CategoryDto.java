package com.elife.gestion.dto;

import java.util.List;

import com.elife.gestion.Dao.entity.Category;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Builder;
import lombok.Data;
@Builder
@Data

public class CategoryDto {

    private Integer id;

    private String code;

    private String designation;

    @JsonIgnore
    private List<ArticleDto> articles;

    public static CategoryDto fromEntity(Category category){
        if(category==null){
         return null;   
        }
        return CategoryDto.builder()
        .id(category.getId())
        .code(category.getCode())
        .designation(category.getDesignation())
        .build();
    } 

      
    public static Category toEntity(CategoryDto categorydto){
        if(categorydto==null){
         return null;   
        }
        Category category = new Category();
        category.setId(categorydto.getId());
        category.setCode(categorydto.getCode());
        category.setDesignation(categorydto.getDesignation());

        return category;

}
}