package com.elife.gestion.Dao.entity;

public enum TypeMvtStk {
    ENTREE, SORTIE, CORRECTION_POS, CORRECTION_NEG

}