package com.elife.gestion.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.elife.gestion.Dao.entity.Client;

public interface ClientRepository extends JpaRepository<Client,Integer> {
  
}