package com.elife.gestion.buisness.services;

import java.util.List;

import com.elife.gestion.dto.EntrepriseDto;

public interface EntrepriseService {
    EntrepriseDto save(EntrepriseDto dto);

  EntrepriseDto findById(Integer id);

  List<EntrepriseDto> findAll();

  void delete(Integer id);
}