package com.elife.gestion.buisness.services;

import java.util.List;

import com.elife.gestion.dto.ChangerMotDePasseUtilisateurDto;
import com.elife.gestion.dto.UtilisateurDto;

public interface UtilisateurService {
    
      UtilisateurDto save(UtilisateurDto dto);

  UtilisateurDto findById(Integer id);

  List<UtilisateurDto> findAll();

  void delete(Integer id);

  UtilisateurDto findByEmail(String email);

  UtilisateurDto changerMotDePasse(ChangerMotDePasseUtilisateurDto dto);
}