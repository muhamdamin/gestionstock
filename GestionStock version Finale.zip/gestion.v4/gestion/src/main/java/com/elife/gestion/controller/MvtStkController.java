package com.elife.gestion.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elife.gestion.buisness.services.MvtStkService;
import com.elife.gestion.dto.MvtStkDto;

@RestController
@RequestMapping("/gestiondestock/v1/mvtstk")
@PreAuthorize("hasAnyRole('ADMIN','USER')")
public class MvtStkController {
      final MvtStkService service;

  
  public MvtStkController(MvtStkService service) {
    this.service = service;
  }

  @GetMapping("/stockreel/{idArticle}")
  @PreAuthorize("hasAuthority('READ_PRIVILEGE') and hasRole('ADMIN')")
   public BigDecimal stockReelArticle(@PathVariable("idArticle") Integer idArticle) {
    return service.stockReelArticle(idArticle);
  }

  @GetMapping("/filter/article/{idArticle}")
  @PreAuthorize("hasAuthority('READ_PRIVILEGE') and hasRole('ADMIN')")
   public List<MvtStkDto> mvtStkArticle(@PathVariable("idArticle") Integer idArticle) {
    return service.mvtStkArticle(idArticle);
  }

  @PostMapping("/entree")
  @PreAuthorize("hasAuthority('READ_PRIVILEGE') and hasRole('ADMIN')")
  public MvtStkDto entreeStock(@RequestBody MvtStkDto dto) {
    return service.entreeStock(dto);
  }

    @PostMapping("/sortie")
    @PreAuthorize("hasAuthority('READ_PRIVILEGE') and hasRole('ADMIN')")
  public MvtStkDto sortieStock(@RequestBody MvtStkDto dto) {
    return service.sortieStock(dto);
  }
  @PostMapping("/correctionpos")
  @PreAuthorize("hasAuthority('WRITE_PRIVILEGE') and hasRole('ADMIN')")
  public MvtStkDto correctionStockPos(@RequestBody MvtStkDto dto) {
    return service.correctionStockPos(dto);
  }
  @PostMapping("/correctionneg")
  @PreAuthorize("hasAuthority('WRITE_PRIVILEGE') and hasRole('ADMIN')")
  public MvtStkDto correctionStockNeg(@RequestBody MvtStkDto dto) {
    return service.correctionStockNeg(dto);
  }
}