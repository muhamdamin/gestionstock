package com.elife.gestion.validator;

import java.util.ArrayList;
import java.util.List;

import com.elife.gestion.dto.LigneCommandeClientDto;

public class LigneCommandeClientValidator {
    public static List<String> validate(LigneCommandeClientDto dto) {
    List<String> errors = new ArrayList<>();
    return errors;
  }
}